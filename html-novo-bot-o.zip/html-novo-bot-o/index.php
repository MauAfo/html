<html>

<head>

	<title>Meu primeiro site em PHP!!</title>
	
	</head>

<body>


<?php
	for ( $i = 0 ; $i < 10 ; $i++ ) 
	{
	
	print ("Linha número " . $i . "<br />");
	
	}
	
		
	
?>


</body>
	
	
	




</html>