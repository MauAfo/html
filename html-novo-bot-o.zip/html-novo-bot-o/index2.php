<html>

<head>

	<title>Meu SEGUNDO site em PHP!!</title>

		
			<style type="text/css">
				.linha {
					font-weight: bold;
					color: red;
					padding-left: 10px;
					line-height: 45px;
					}
			</style>
			
	
	</head>

<body>


<?php
	for ( $i = 0 ; $i < 10 ; $i++ ) 
	{
	
	print ("<span class=\"linha\">Linha número " . $i . "</span><br />");
	
	}
	
		
	
?>


</body>
	
	<script type="text/javascript">
	$(document).ready(function() {
	alert(PARABÉNS!!!!);
	});
	
	</script>
	
</html>